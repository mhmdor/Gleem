<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

// Route::get('/', function () {
//     return view('auth.login');
// });

Auth::routes();

Route::get('/', [App\Http\Controllers\HomeController::class, 'index'])->name('home');

Route::any('/Create/Client', [App\Http\Controllers\ClientController::class, 'createClient'])->name('createClient');

Route::get('/Client', [App\Http\Controllers\ClientController::class, 'getClient'])->name('getClient');

Route::get('/SingleClient/{id}', [App\Http\Controllers\ClientController::class, 'getSingleClient'])->name('getSingleClient');

Route::get('/Company', [App\Http\Controllers\CompanyController::class, 'getCompanies'])->name('getCompany');

Route::get('/SingleCompany/{id}', [App\Http\Controllers\CompanyController::class, 'getSingleCompany'])->name('getSingleCompany');